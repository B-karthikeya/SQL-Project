-- Final project on walmart data set
-- task1 
SELECT 
    Branch, 
    DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS Month,
    SUM(Total) AS MonthlySales
FROM walmart_sales
GROUP BY Branch, Month
ORDER BY Branch, Month;

-- task2
SELECT 
    Branch,
    `Product line`,
    SUM(`gross income`) AS TotalProfit
FROM walmart_sales
GROUP BY Branch, `Product line`
ORDER BY Branch, TotalProfit DESC;

-- task3
SELECT 
    `Customer ID`, 
    SUM(Total) AS TotalSpent,
    CASE 
        WHEN SUM(Total) >= 500 THEN 'High'
        WHEN SUM(Total) >= 250 THEN 'Medium'
        ELSE 'Low'
    END AS SpendingCategory
FROM walmart_sales
GROUP BY `Customer ID`;

-- task4 
SELECT * 
FROM walmart_sales ws
JOIN (
    SELECT `Product line`, 
           AVG(Total) AS avg_total, 
           STDDEV(Total) AS std_total
    FROM walmart_sales
    GROUP BY `Product line`
) stats
ON ws.`Product line` = stats.`Product line`
WHERE Total > avg_total + 2 * std_total
   OR Total < avg_total - 2 * std_total;

-- task5 
SELECT 
    City,
    Payment,
    COUNT(*) AS Count
FROM walmart_sales
GROUP BY City, Payment
ORDER BY City, Count DESC;

-- task6
SELECT 
    Gender,
    DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS Month,
    SUM(Total) AS Sales
FROM walmart_sales
GROUP BY Gender, Month
ORDER BY Month, Gender;

-- task7
SELECT 
    `Customer type`, 
    `Product line`, 
    SUM(Total) AS TotalSales
FROM walmart_sales
GROUP BY `Customer type`, `Product line`
ORDER BY `Customer type`, TotalSales DESC;

-- task8
SELECT DISTINCT w1.`Customer ID`
FROM walmart_sales w1
JOIN walmart_sales w2 
ON w1.`Customer ID` = w2.`Customer ID`
   AND w1.`Invoice ID` != w2.`Invoice ID`
   AND ABS(DATEDIFF(STR_TO_DATE(w1.Date, '%d-%m-%Y'), STR_TO_DATE(w2.Date, '%d-%m-%Y'))) <= 30;

-- task9
SELECT 
    `Customer ID`,
    SUM(Total) AS TotalSales
FROM walmart_sales
GROUP BY `Customer ID`
ORDER BY TotalSales DESC
LIMIT 5;

-- task10
SELECT 
    DAYNAME(STR_TO_DATE(Date, '%d-%m-%Y')) AS DayOfWeek,
    SUM(Total) AS TotalSales
FROM walmart_sales
GROUP BY DayOfWeek
ORDER BY FIELD(DayOfWeek, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');

